package com.example.tariflerim;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
public class haftalikMenu extends AppCompatActivity {
sqllite_katmani mDataBaseHelper;
int deger1,deger2,deger3,deger4,deger5,deger6;
String val;
String yemek [] = new String [6];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_haftalik_menu);
        mDataBaseHelper = new sqllite_katmani(this);
        ListView yemekler= findViewById(R.id.liste1);



        final ArrayList array_list1 = mDataBaseHelper.getCorba();
        final ArrayList array_list2 = mDataBaseHelper.getSalata();
       final ArrayList array_list3 = mDataBaseHelper.getAna();
        final ArrayList array_list4 = mDataBaseHelper.getZeytinyagli();
        final ArrayList array_list5 = mDataBaseHelper.getTuzlu();
        final ArrayList array_list6 = mDataBaseHelper.getTatli();

        deger1=array_list1.size();
        System.out.println("*"+deger1);
        deger2=array_list2.size();
        deger3=array_list3.size();
        deger4=array_list4.size();
        deger5=array_list5.size();
        deger6=array_list6.size();

        int random1 = (int) (Math.random() * deger1);
        yemek[0]= array_list1.get(random1).toString();
        int random2= (int) (Math.random()*deger2);
        yemek[1]= array_list2.get(random2).toString();
        int random3= (int) (Math.random()*deger3);
        yemek[2]= array_list3.get(random3).toString();
        int random4= (int) (Math.random()*deger4);
        yemek[3]= array_list4.get(random4).toString();
        int random5= (int) (Math.random()*deger5);
        yemek[4]= array_list5.get(random5).toString();
        int random6= (int) (Math.random()*deger6);
        yemek[5]= array_list6.get(random6).toString();

        ArrayAdapter<String> arrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,yemek);
        yemekler.setAdapter(arrayAdapter);


        yemekler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                val= yemekler.getItemAtPosition(position).toString();
                Toast.makeText(haftalikMenu.this, val,Toast.LENGTH_SHORT).show();
                Intent i = new Intent(haftalikMenu.this, tarifDetay.class);
                i.putExtra("ad",val);
                startActivity(i);
            }
        });

    }
}