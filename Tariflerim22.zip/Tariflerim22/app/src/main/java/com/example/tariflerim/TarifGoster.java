package com.example.tariflerim;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TarifGoster extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    ImagesAdapter imagesAdapter;
    RecyclerView mRecyclerView;
    private static final int IMAGES_LOADER = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarif_goster);

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        imagesAdapter = new ImagesAdapter(this);
        mRecyclerView.setAdapter(imagesAdapter);
        getLoaderManager().initLoader(IMAGES_LOADER, null, this);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        String[] projection = {
                sqllite_katmani.ROW_ID,
                sqllite_katmani.ROW_RESIM,
                sqllite_katmani.ROW_AD,
                sqllite_katmani.ROW_CATEGORY,
                sqllite_katmani.ROW_MALZEMELER,
                sqllite_katmani.ROW_HAZIRLANIS,
                sqllite_katmani.ROW_SURE,
                sqllite_katmani.ROW_PISIRME,
                sqllite_katmani.ROW_NOTLAR
        };

        return new CursorLoader(this,
                ImagesProvider.CONTENT_URI,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        imagesAdapter.swapCursor(cursor);

    }
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        imagesAdapter.swapCursor(null);

    }
}