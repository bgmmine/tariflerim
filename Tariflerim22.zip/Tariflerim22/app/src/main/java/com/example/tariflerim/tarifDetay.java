package com.example.tariflerim;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.ByteArrayOutputStream;
public class tarifDetay extends AppCompatActivity {
    sqllite_katmani mDataBaseHelper;
    TextView etMalzeme, etTarifAdi,etmHazirlanis, etSure, etNot, etCategory,etPisirme;
    Button btndegisiklik,btnSil;
    ImageView profileImageView;
   String add,id;
    String idd,ad,malzeme,kategori,hazirlanis,sure,pisirme,not;
    byte[] image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bundle extras = getIntent().getExtras();
         //id = extras.getString("id");
       // byte[] images = extras.getByteArray("image");
         add = extras.getString("ad");
        /*String kategori= extras.getString("kategori");
        String malzeme = extras.getString("malzeme");
        String hazirlanis = extras.getString("hazirlanis");
        String sure = extras.getString("sure");
        String pisirme = extras.getString("pisirme");
        String not = extras.getString("not");*/
        super.onCreate(savedInstanceState);
        mDataBaseHelper = new sqllite_katmani(this);
        setContentView(R.layout.activity_tarif_detay);
        etTarifAdi = findViewById(R.id.etTarifAdi);
        etMalzeme = findViewById(R.id.etMalzeme);
        profileImageView = findViewById(R.id.profileImageView);
        etCategory= findViewById(R.id.etCategory);
        etPisirme= findViewById(R.id.etPisirme);
        etmHazirlanis = findViewById(R.id.etmHazirlanis);
        etSure = findViewById(R.id.etSure);
        etNot = findViewById(R.id.etmNotlar);
        btndegisiklik = findViewById(R.id.btnDegisiklik);
        btnSil=findViewById(R.id.btnSİlme);
        System.out.println("***"+add);
       // System.out.println("***"+id);
        Cursor data1 =mDataBaseHelper.Search(add);

        if (data1.getCount()==0){
            Toast.makeText(getApplicationContext(),"Kayıt bulunamadı",Toast.LENGTH_SHORT).show();
            return;
        }
        while(data1.moveToNext()) {
            idd=data1.getString(0);
            image= data1.getBlob(1);
            ad=data1.getString(2);
            kategori=data1.getString(3);
            malzeme=data1.getString(4);
            hazirlanis=data1.getString(5);
            sure=data1.getString(6);
            pisirme=data1.getString(7);
            not=data1.getString(8);
        }
        Bitmap bmp = BitmapFactory.decodeByteArray(image, 0, image.length);
        profileImageView.setImageBitmap(Bitmap.createScaledBitmap(bmp, 200,
                200, false));
        etTarifAdi.setText(ad);
        etCategory.setText(kategori);
        etMalzeme.setText(malzeme);
        etmHazirlanis.setText(hazirlanis);
        etSure.setText(sure);
        etPisirme.setText(pisirme);
        etNot.setText(not);

        btndegisiklik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                profileImageView.setDrawingCacheEnabled(true);
                profileImageView.buildDrawingCache();
                Bitmap bitmap = profileImageView.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] resim = baos.toByteArray();
                String isim=etTarifAdi.getText().toString();
                String kategori = etCategory.getText().toString();
                String malzemeler = etMalzeme.getText().toString();
                String hazirlanis = etmHazirlanis.getText().toString();
                String sure = etSure.getText().toString();
                String pisme = etPisirme.getText().toString();
                String not = etNot.getText().toString();

                sqllite_katmani vt = new sqllite_katmani(tarifDetay.this);
                vt.duzenle(resim,ad,kategori,malzemeler,hazirlanis,sure,pisme,not);
                Toast.makeText(tarifDetay.this,"Başarılı bir şekilde kaydedildi",Toast.LENGTH_SHORT).show();
                Intent gecisYap1 = new Intent(tarifDetay.this, TarifGoster.class);
                startActivity(gecisYap1);
            }
        });
        btnSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sqllite_katmani vt = new sqllite_katmani(tarifDetay.this);
                String isim=etTarifAdi.getText().toString();
                vt.VeriSil(isim);
                Intent gecisYap1 = new Intent(tarifDetay.this, TarifGoster.class);
                startActivity(gecisYap1);
            }
        });
    }
}