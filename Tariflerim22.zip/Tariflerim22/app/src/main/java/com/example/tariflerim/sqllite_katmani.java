package com.example.tariflerim;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
public class sqllite_katmani extends SQLiteOpenHelper {
    public static final String  DB_AD = "tariflerim";
    public static final String  DB = "tariflerim.db";
    public static final String  ROW_ID = "yemekID";
    public static final String ROW_RESIM ="image";
    public static final String ROW_AD="yemekAdi";
    public static final String ROW_CATEGORY="kategori";
    public static final String ROW_MALZEMELER="malzemeler";
    public static final String ROW_HAZIRLANIS="hazirlanis";
    public static final String ROW_SURE="sure";
    public static final String ROW_PISIRME="pisirmesekli";
    public static final String ROW_NOTLAR="notlar";
    ContentResolver mContentResolver;
    public sqllite_katmani(Context c) {
        super(c,DB , null, 1);
        mContentResolver = c.getContentResolver();
    }

    public void onCreate(SQLiteDatabase db) {
        //ilk çalıştığında ya da ilk uygulama indirildiğinde ne yapılıcaksa buraya yazılır
        db.execSQL("CREATE TABLE "+DB_AD+"("
                +ROW_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"
                +ROW_RESIM+" BLOB,"
                +ROW_AD+" TEXT NOT NULL,"
                + ROW_CATEGORY+" TEXT NOT NULL, "
                + ROW_MALZEMELER+" TEXT,"
                +ROW_HAZIRLANIS+" TEXT, "
                + ROW_SURE+" TEXT, "
                +ROW_PISIRME+" TEXT,"
                + ROW_NOTLAR+" TEXT)");
        String sql2 = "create table  alisverislistesi ( malzemeId integer primary key not null , malzeme_adi text not null)";
        db.execSQL(sql2);
        String sql3 = "insert into alisverislistesi (malzeme_adi) values  ('Avakado'), ('Armut'), ('Ayva'),('AyçiçekYağı'), ('Balkabağı'), ('Balık'), ('Bamya'), ('BeyazPeynir'), ('Bezelye'), ('BiberSalçası'),('Biftek'), ('Böğürtlen'), ('Bulgur'), ('Brokoli')" +
                ", ('Çilek'), ('Domates'), ('DomatesSalçası'),('DomatesPüresi'),('Elma'),('Enginar'),('Erik'),('Fasulye'),('Fesleğen'),('Havuç'),('Ispanak'),('İrmik'),('Kabak'),('Karalahana'),('Karnıbahar'),('Kayısı'),('KaşarPeyniri'),('Karabiber')" +
                ",('KabartmaTozu'),('Kekik'),('Kimyon'),('KırmızıBiber'),('Kivi'),('Kıyma'),('Krema'),('Kuşbaşı'),('Kurufasulye'),('Lahana'),('Limon'),('Mantar'),('Mandalina'),('Margarin'),('Makarna'),('Marul'),('Maydanoz'),('Maya'),('Mercimek'),('Mısır'),('MısırÖzüYağı')" +
                ",('MisketLimonu'),('Muz'),('Nane'),('Patates'),('Pırasa'),('Pirinç'),('Portakal'),('PulBiber'),('PudraŞekeri'),('Roka'),('Salatalık'),('Salam'),('Sarımsak'),('Soğan'),('Sosis'),('Sucuk'),('Susam'),('Süt'),('Sirke'),('Şeftali'),('Şehriye'),('Şeker'),('ŞekerVanilin')" +
                ",('Tavuk'),('TavukGöğsü'),('TavukBudu'),('Tarçın'),('Tereyağı'),('Tuz'),('Turp'),('Un'),('Üzüm'),('YeşilSoğan'),('Yulaf'),('Yoğurt'),('Yumurta'),('Zeytinyağı')";
        db.execSQL(sql3);

    }
    public void onUpgrade(SQLiteDatabase db, int eski, int yeni) {
        // versiyon upgrade i yapıldığında ne yapılıcaksa buraya yazılır.
        db.execSQL("DROP  TABLE tariflerim ");
        onCreate(db);
    }
    // malmemeleri db den alma
    public Cursor getMalzeme() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM alisverislistesi";
        Cursor data = db.rawQuery(query, null);
        return data;
    }
    public void addTarif( byte []image,String name, String category,  String material, String yapilis, String zaman, String pisir, String not) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            ContentValues cv = new ContentValues();
            cv.put(ROW_RESIM,image);
            cv.put(ROW_AD, name);
            cv.put(ROW_CATEGORY, category);
            cv.put(ROW_MALZEMELER, material);
            cv.put(ROW_HAZIRLANIS, yapilis);
            cv.put(ROW_SURE, zaman);
            cv.put(ROW_PISIRME, pisir);
            cv.put(ROW_NOTLAR, not);
            db.insert(DB_AD, null, cv);
        } catch(Exception e){
        }
        db.close();;
    }
    // tarif düzenleme
    public void duzenle(byte []image,String name, String category,  String material, String yapilis, String zaman, String pisir, String not) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            ContentValues cv = new ContentValues();
            cv.put(ROW_AD, name);
            cv.put(ROW_CATEGORY, category);
            cv.put(ROW_MALZEMELER, material);
            cv.put(ROW_HAZIRLANIS, yapilis);
            cv.put(ROW_SURE, zaman);
            cv.put(ROW_PISIRME, pisir);
            cv.put(ROW_NOTLAR, not);
            String where = ROW_AD + " = '" + name + "'";
            db.update(DB_AD, cv, where, null);
        } catch (Exception e) {
        }
    }
    // tarif silme
    public void VeriSil(String  name){
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            String where = ROW_AD + " = '" + name + "'" ;
            db.delete(DB_AD,where,null);
        }catch (Exception e){
        }
    }

    public Cursor getData(){
        SQLiteDatabase db= this.getWritableDatabase();
        String query = "SELECT * FROM tariflerim";
        Cursor data = db.rawQuery(query, null);
        return data;
    }
    public Cursor Search(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        String arama3 = "SELECT * FROM tariflerim WHERE yemekAdi = '"+ name +"'";
        Cursor data1 = db.rawQuery(arama3, null);
        return data1 ;
    }
    public ArrayList getCorba() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> array_list = new ArrayList<String>();
        Cursor res = db.rawQuery( "SELECT * FROM tariflerim WHERE kategori = 'Çorba'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex("yemekAdi")));
            res.moveToNext();
        }
        return array_list;
    }
    public ArrayList getSalata() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> array_list = new ArrayList<String>();
        Cursor res = db.rawQuery( "SELECT * FROM tariflerim WHERE kategori = 'Salata/Meze'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex("yemekAdi")));
            res.moveToNext();
        }
        return array_list;
    }
    public ArrayList getAna() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> array_list = new ArrayList<String>();
        Cursor res = db.rawQuery( "SELECT * FROM tariflerim WHERE kategori = 'Ana Yemek'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex("yemekAdi")));
            res.moveToNext();
        }
        return array_list;
    }
    public ArrayList getZeytinyagli() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> array_list = new ArrayList<String>();
        Cursor res = db.rawQuery( "SELECT * FROM tariflerim WHERE kategori = 'Zeytinyağlı'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex("yemekAdi")));
            res.moveToNext();
        }
        return array_list;
    }
    public ArrayList getTuzlu() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> array_list = new ArrayList<String>();
        Cursor res = db.rawQuery( "SELECT * FROM tariflerim WHERE kategori = 'Tuzlu Aperatif'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex("yemekAdi")));
            res.moveToNext();
        }
        return array_list;
    }
    public ArrayList getTatli() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> array_list = new ArrayList<String>();
        Cursor res = db.rawQuery( "SELECT * FROM tariflerim WHERE kategori = 'Tatlı'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex("yemekAdi")));
            res.moveToNext();
        }
        return array_list;
    }

}
