package com.example.tariflerim;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;


public class ImagesAdapter extends RecyclerView.Adapter<ImagesAdapter.ImagesViewHolder> {

    private String deneme ="TarifGoster";
    private Cursor mCursor;
    private Context mContext;
    String kategori ;
    String malzeme;
    String hazirlanis;
    String sure ;
    String pisirme ;
    String not ;
    String id;
    byte[] images;
    public ImagesAdapter(Context mContext) {
        this.mContext = mContext;
    }


    @Override
    public ImagesViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
      View view = inflater.inflate(R.layout.image_item, parent, false);

        return new ImagesViewHolder(view);
    }
    // veriler db den alıp gerekli nesnelere bağlama
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(ImagesViewHolder holder, int position) {
        int idIndex =  mCursor.getColumnIndex(sqllite_katmani.ROW_ID);
        int fragranceName = mCursor.getColumnIndex(sqllite_katmani.ROW_RESIM);
        int isimIndex= mCursor.getColumnIndex(sqllite_katmani.ROW_AD);
        int kategoriIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_CATEGORY);
        int malzemeIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_MALZEMELER);
        int hazirlanisIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_HAZIRLANIS);
        int sureIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_SURE);
        int pisirmeIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_PISIRME);
        int notIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_NOTLAR);
        System.out.println("***"+kategoriIndex);
        mCursor.moveToPosition(position);
        System.out.println("***"+position);
        id=mCursor.getString(idIndex);
         images = mCursor.getBlob(fragranceName);
         String isim= mCursor.getString(isimIndex);
         kategori = mCursor.getString(kategoriIndex);
         malzeme= mCursor.getString(malzemeIndex);
         hazirlanis = mCursor.getString(hazirlanisIndex);
         sure = mCursor.getString(sureIndex);
         pisirme = mCursor.getString(pisirmeIndex);
        not = mCursor.getString(notIndex);
        System.out.println("***"+malzeme);
        Bitmap bmp = BitmapFactory.decodeByteArray(images, 0, images.length);
        holder.image.setImageBitmap(Bitmap.createScaledBitmap(bmp, 200,
                200, false));
        holder.textad.setText(isim);

    }
    @Override
    public int getItemCount() {
        if (mCursor == null) {
            return 0;
        }
        return mCursor.getCount();
    }
    public Cursor swapCursor(Cursor c) {
        if (mCursor == c) {
            return null;
        }
        Cursor temp = mCursor;
        this.mCursor = c;
        if (c != null) {
            this.notifyDataSetChanged();
        }
        return temp;
    }
    public class ImagesViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView textad;
        public ImagesViewHolder(View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.imageProf);
            textad= itemView.findViewById(R.id.twad);
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String ad=textad.getText().toString();
                    Intent i=new Intent(mContext,tarifDetay.class);
                    i.putExtra("id",id);

                    i.putExtra("ad",ad);

                    mContext.startActivity(i);
                }
            });
        }

    }

}