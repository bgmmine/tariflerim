package com.example.tariflerim;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Arama extends AppCompatActivity {
            Button btnsearch;
            TextView tvSearch;
            String word;
            String id,ad,malzeme,kategori,hazirlanis,sure,pisirme,not;
            byte[] image;
    sqllite_katmani mDataBaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arama);
            btnsearch=findViewById(R.id.btnAra);
            tvSearch=findViewById(R.id.etSearch);
            mDataBaseHelper = new sqllite_katmani(this);

            btnsearch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    word = tvSearch.getText().toString();
                    Cursor data1 =mDataBaseHelper.Search(word);

                    if (data1.getCount()==0){
                        Toast.makeText(getApplicationContext(),"Kayıt bulunamadı",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    while(data1.moveToNext()) {
                        id=data1.getString(0);
                        image= data1.getBlob(1);
                        ad=data1.getString(2);
                        kategori=data1.getString(3);
                        malzeme=data1.getString(4);
                        hazirlanis=data1.getString(5);
                        sure=data1.getString(6);
                        pisirme=data1.getString(7);
                        not=data1.getString(8);
                    }

                    Intent i = new Intent(Arama.this, tarifDetay.class);
                    i.putExtra("id",id);
                    i.putExtra("image",image);
                    i.putExtra("ad",ad);
                    i.putExtra("kategori",kategori);
                    i.putExtra("malzeme",malzeme);
                    i.putExtra("hazirlanis",hazirlanis);
                    i.putExtra("sure",sure);
                    i.putExtra("pisirme",pisirme);
                    i.putExtra("not",not);
                    startActivity(i);
                }
            });

    }
}