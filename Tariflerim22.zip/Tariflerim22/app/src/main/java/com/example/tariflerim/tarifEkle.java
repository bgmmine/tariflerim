package com.example.tariflerim;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NavUtils;
import androidx.core.content.ContextCompat;
import com.afollestad.materialdialogs.MaterialDialog;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public  class tarifEkle extends AppCompatActivity implements View.OnClickListener {
    sqllite_katmani mDataBaseHelper;
    TextView etMalzeme, etTarifAdi,etmHazirlanis, etSure, etNot;
    Button btnekleme, pick_image;
    ImageView profileImageView;
    String value,pismedegeri;
    Spinner sp,sppisme;

    private static final int SELECT_PHOTO = 1;
    private static final int CAPTURE_PHOTO = 2;
    private ProgressDialog progressBar;
    private int progressBarStatus = 0;
    private Handler progressBarbHandler = new Handler();
    private boolean hasImageChanged = false;
    Bitmap thumbnail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarif_ekle);
        Toolbar myToolbar = findViewById(R.id.toolbar);
        myToolbar.setTitle("Tarif Ekleme");
        setSupportActionBar(myToolbar);
        String kategori[] = getResources().getStringArray(R.array.category);
        String pisme[]= getResources().getStringArray(R.array.pisme);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sp = findViewById(R.id.spinner);
        sppisme=findViewById(R.id.spPisme);
        etTarifAdi = findViewById(R.id.etTarifAdi);
        etMalzeme = findViewById(R.id.etMalzeme);
        etmHazirlanis = findViewById(R.id.etmHazirlanis);
        etSure = findViewById(R.id.etSure);
        etNot = findViewById(R.id.etmNotlar);
        btnekleme = findViewById(R.id.btnekle);
        profileImageView = findViewById(R.id.profileImageView);
        pick_image = findViewById(R.id.pick_image);
        mDataBaseHelper = new sqllite_katmani(this);

        //spinner array adapterları
        ListAdapter aaa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, kategori);
        sp.setAdapter((SpinnerAdapter) aaa);
        ListAdapter a = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pisme);
        sppisme.setAdapter((SpinnerAdapter) a);
        pick_image.setOnClickListener(this);

        if (ContextCompat.checkSelfPermission(tarifEkle.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            profileImageView.setEnabled(false);
            ActivityCompat.requestPermissions(tarifEkle.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        } else {
            profileImageView.setEnabled(true);
        }

        // spinner kategoriden bir şey seçildiğinde ne yapılıcağı
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view, int position, long id) {
                value = sp.getSelectedItem().toString();
                Toast.makeText(tarifEkle.this, value, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(tarifEkle.this, "tıklanmadı", Toast.LENGTH_SHORT).show();
            }
        });
        sppisme.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view, int position, long id) {
                pismedegeri = sppisme.getSelectedItem().toString();
                Toast.makeText(tarifEkle.this, pismedegeri, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(tarifEkle.this, "tıklanmadı", Toast.LENGTH_SHORT).show();
            }
        });
 // db ekleme
        btnekleme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                profileImageView.setDrawingCacheEnabled(true);
                profileImageView.buildDrawingCache();
                Bitmap bitmap = profileImageView.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                String ad;
                    if(etTarifAdi.length() != 0){
                         ad = etTarifAdi.getText().toString();
                    }
                    else{Toast.makeText(tarifEkle.this, "Tarifinizin ismini giriniz!!", Toast.LENGTH_LONG).show();}
                    
                byte[] resim = baos.toByteArray();
                    ad=etTarifAdi.getText().toString();
                String kategori = value;
                String malzemeler = etMalzeme.getText().toString();
                String hazirlanis = etmHazirlanis.getText().toString();
                String sure = etSure.getText().toString();
                String pisme = pismedegeri;
                String not = etNot.getText().toString();
                sqllite_katmani vt = new sqllite_katmani(tarifEkle.this);
                vt.addTarif(resim,ad,kategori,malzemeler,hazirlanis,sure,pisme,not);
                Toast.makeText(tarifEkle.this,"Başarılı bir şekilde kaydedildi",Toast.LENGTH_SHORT).show();
                temizle();
            }
        });
    }
    // oncrate bitimi
    @Override
    public void onClick(final View view) {
        switch (view.getId()) {
            case R.id.pick_image:
                new MaterialDialog.Builder(this)
                        .title("Resmi ayarlayınız")
                        .items(R.array.uploadImages)
                        .itemsIds(R.array.itemIds)
                        .itemsCallback(new MaterialDialog.ListCallback() {
                            @Override
                            public void onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                                switch (which) {
                                    case 0:
                                        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                                        photoPickerIntent.setType("image/*");
                                        startActivityForResult(photoPickerIntent, SELECT_PHOTO);
                                        break;
                                    case 1:
                                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                        startActivityForResult(intent, CAPTURE_PHOTO);
                                        break;
                                    case 2:
                                        profileImageView.setImageResource(R.mipmap.ic_launcher_round);
                                        break;
                                }
                            }
                        })
                        .show();
                break;
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 0) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                profileImageView.setEnabled(true);
            }
        }
    }
    public void setProgressBar() {
        progressBar = new ProgressDialog(this);
        progressBar.setCancelable(true);
        progressBar.setMessage("Please wait...");
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();
        progressBarStatus = 0;
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (progressBarStatus < 100) {
                    progressBarStatus += 30;

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    progressBarbHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(progressBarStatus);
                        }
                    });
                }
                if (progressBarStatus >= 100) {
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    progressBar.dismiss();
                }

            }
        }).start();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SELECT_PHOTO) {
            if (resultCode == RESULT_OK) {
                try {
                    final Uri imageUri = data.getData();
                    final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    //set Progress Bar
                    setProgressBar();
                    //set profile picture form gallery
                    profileImageView.setImageBitmap(selectedImage);


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }

        } else if (requestCode == CAPTURE_PHOTO) {
            if (resultCode == RESULT_OK) {
                onCaptureImageResult(data);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    // içini temizleme methodu
    public void temizle() {
        etTarifAdi.setText(null);
        etMalzeme.setText(null);
        etmHazirlanis.setText(null);
        etSure.setText(null);
        etNot.setText(null);
    }
    // geri gitme butonu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            Intent geributonu = new Intent(getApplicationContext(), MainActivity.class);
            NavUtils.navigateUpTo(this, geributonu);
            return true;
        }
        return true;
    }

    private void onCaptureImageResult(Intent data) {
        thumbnail = (Bitmap) data.getExtras().get("data");
        setProgressBar();
        profileImageView.setMaxWidth(200);
        profileImageView.setImageBitmap(thumbnail);

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}