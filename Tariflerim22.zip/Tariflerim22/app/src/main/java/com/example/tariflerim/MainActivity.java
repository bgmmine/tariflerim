package com.example.tariflerim;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
TextView tvGiris;
Button btnTarifEkle, btnTariflerim, btnHaftalikPlan,  btnzamanlayici, btnListe,btnArama ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvGiris=findViewById(R.id.tvGiris);
        btnTarifEkle=findViewById(R.id.btnTarifEkle);
        btnTariflerim=findViewById(R.id.btnTariflerim);
        btnHaftalikPlan=findViewById(R.id.btnHaftalikPlan);
        btnzamanlayici=findViewById(R.id. btnZamanlayici);
        btnListe=findViewById(R.id.btnListe);
        btnArama=findViewById(R.id.btnArama);
        btnTarifEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gecisYap1 = new Intent(MainActivity.this, tarifEkle.class);
                startActivity(gecisYap1);
            }
        });
        btnTariflerim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gecis= new Intent(MainActivity.this, TarifGoster.class);
                startActivity(gecis);
            }
        });
        btnListe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent liste = new Intent(MainActivity.this,alisveris_listesi.class);
                startActivity(liste);
            }
        });
        btnzamanlayici.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent zaman = new Intent(MainActivity.this,zamanlayici.class);
                startActivity(zaman);
            }
        });
        btnArama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ara = new Intent(MainActivity.this,Arama.class);
                startActivity(ara);
            }
        });
        btnHaftalikPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent liste = new Intent(MainActivity.this,haftalikMenu.class);
                startActivity(liste);
            }
        });
    }
}